const std = @import("std");
const builtin = @import("builtin");
const Graph = @import("graph.zig");
const Storage = @import("../storage/storage.zig");
const Tensor = @import("tensor.zig");
const ScalarValue = @import("../storage/dtype.zig").ScalarValue;

var debug_warning_emitted = std.atomic.Value(u8).init(0);

fn EmbeddedStorage(comptime bytes: []const u8, comptime alignment: usize) type {
    const contents = bytes;
    return struct {
        const storage: [contents.len]u8 align(alignment) = contents[0..].*;
    };
}

fn LiteralStorage(comptime value: ScalarValue) type {
    const T = value.dtype().Scalar();
    return struct {
        const storage: [1]T = .{value.get(value.dtype())};
    };
}

fn PackedEmbeddedStorage(
    comptime bytes: []const u8,
    comptime info: anytype,
    comptime alignment: usize,
) type {
    const element_bytes = info.dtype.byteSize();
    const element_count = info.shape.elementCount();
    const contents = comptime blk: {
        // Packing work scales with both the element count and rank because
        // each logical index is decomposed into coordinates. Large embedded
        // parameter tensors legitimately exceed Zig's default comptime quota.
        @setEvalBranchQuota(element_count * (info.shape.rank + 8) + 1000);
        var packed_bytes: [bytes.len]u8 = undefined;
        for (0..element_count) |logical_index| {
            var remaining = logical_index;
            var physical_index = info.layout.offset;
            var axis = info.shape.rank;
            while (axis > 0) {
                axis -= 1;
                const extent = info.shape.at(axis);
                const coordinate = remaining % extent;
                remaining /= extent;
                if (info.layout.strides[axis] < 0) {
                    @compileError("embedded source packing does not support negative strides");
                }
                physical_index += coordinate *
                    @as(usize, @intCast(info.layout.strides[axis]));
            }

            const source_start = logical_index * element_bytes;
            const destination_start = physical_index * element_bytes;
            @memcpy(
                packed_bytes[destination_start..][0..element_bytes],
                bytes[source_start..][0..element_bytes],
            );
        }
        break :blk packed_bytes;
    };

    return struct {
        const storage: [contents.len]u8 align(alignment) = contents;
    };
}

fn hasLogicalRowMajorLayout(comptime info: anytype) bool {
    const expected = @TypeOf(info.layout).contiguous(info.shape);
    if (info.layout.offset != expected.offset) return false;
    for (0..info.shape.rank) |axis| {
        if (info.layout.strides[axis] != expected.strides[axis]) return false;
    }
    return true;
}

pub fn Executable(
    comptime SourceKey: type,
    comptime capacities: Graph.Capacity,
    comptime raw: anytype,
    comptime semantic_optimization: anytype,
    comptime SemanticValidated: type,
    comptime semantic_analysis: anytype,
    comptime executable_search: anytype,
    comptime selection: @import("../compiler/search.zig").SelectionOptions,
    comptime Validated: type,
    comptime lifetimes: anytype,
    comptime SourcePlan: type,
    comptime OutputPlan: type,
    comptime source_name_table: []const [:0]const u8,
) type {
    const graph = Validated.graph;
    const plan = Storage.MemoryPlan(capacities, graph, lifetimes, SourcePlan, OutputPlan);
    return struct {
        pub const SourceKeyType = SourceKey;
        pub const SourceError = error{SourceSizeMismatch};
        pub const OutputError = error{OutputSizeMismatch};
        pub const program = graph;
        pub const structural_fingerprint = @import("../compiler/analysis/fingerprint.zig").executable(graph);
        pub const memory_plan = plan;
        pub const internal_capacity = capacities;
        pub const raw_graph = raw;
        pub const semantic_graph = SemanticValidated.graph;
        pub const semantic_optimization_result = semantic_optimization;
        pub const semantic_provenance = semantic_optimization.provenance;
        pub const semantic_analysis_result = semantic_analysis;
        pub const reference_executable_candidate = executable_search.reference;
        pub const executable_candidate_frontier = executable_search.frontier;
        pub const executable_candidate_count = executable_search.generated_count;
        pub const representation_candidate_count = executable_search.representation_candidate_count;
        pub const fusion_candidate_count = executable_search.fusion_candidate_count;
        pub const layout_candidate_count = executable_search.layout_candidate_count;
        pub const remap_candidate_count = executable_search.remap_candidate_count;
        pub const contraction_candidate_count = executable_search.contraction_candidate_count;
        pub const generated_contraction_strategies = executable_search.generated_contraction_strategies;
        pub const selection_options = selection;
        pub const selected_executable_candidate_index = executable_search.selectedIndex(selection);
        pub const selected_executable_candidate = executable_search.selected(selection);
        pub const lifetime_analysis = lifetimes;
        pub const source_plan = SourcePlan;
        pub const output_plan = OutputPlan;
        pub const source_names = source_name_table;

        pub const Runtime = struct {
            const Self = @This();
            pub const memory_plan = plan;

            memory: [plan.byte_count]u8 align(plan.alignment) = undefined,
            bound_sources: [capacities.max_sources]?[]const u8 = @splat(null),
            bound_outputs: [graph.output_ct]?[]u8 = @splat(null),

            pub fn init() Self {
                if (comptime builtin.mode == .debug and builtin.os.tag != .freestanding) {
                    if (!@inComptime()) {
                        if (debug_warning_emitted.swap(1, .monotonic) == 0) {
                            std.log.warn("ZGC executable is built in Debug mode; runtime execution may be much slower than ReleaseFast", .{});
                        }
                    }
                }
                return .{
                    .memory = @splat(0),
                    .bound_sources = @splat(null),
                    .bound_outputs = @splat(null),
                };
            }

            pub fn run(exe: *Self) void {
                if (comptime OutputPlan.output_binding == .bound) {
                    inline for (0..graph.output_ct) |output_index| {
                        if (exe.bound_outputs[output_index] == null) @panic("runtime output has not been bound");
                    }
                    if (exe.outputBindingsOverlap()) @panic("bound output buffers overlap another active binding");
                }
                @setEvalBranchQuota(10_000 + graph.node_ct * 2_048);
                inline for (0..graph.node_ct) |node_id| {
                    exe.executeNode(node_id);
                }
            }

            pub fn outputView(runtime: *const Self, comptime output_index: usize) blk: {
                if (output_index >= graph.output_ct) {
                    @compileError("output index is outside the graph's outputs");
                }
                const tensor_id = graph.outputs[output_index].?;
                break :blk Validated.ConstView(tensor_id);
            } {
                const tensor_id = graph.outputs[output_index].?;
                return runtime.constTensorView(tensor_id);
            }

            /// Borrow caller-owned physical storage for one output. All outputs
            /// must be bound before run() when executable outputs are bound.
            pub fn bindOutput(
                runtime: *Self,
                comptime output_index: usize,
                values: []outputScalar(output_index),
            ) OutputError!void {
                if (comptime OutputPlan.output_binding != .bound) {
                    @compileError("bindOutput requires executableWith(.{ .outputs = zgc.memory.Output.bound })");
                }
                const info = comptime outputInfo(output_index);
                if (values.len != info.shape.elementCount()) return error.OutputSizeMismatch;
                runtime.bound_outputs[output_index] = std.mem.sliceAsBytes(values);
            }

            pub fn outputIsBound(runtime: *const Self, comptime output_index: usize) bool {
                if (comptime OutputPlan.output_binding != .bound) {
                    @compileError("outputIsBound requires bound executable outputs");
                }
                _ = comptime outputInfo(output_index);
                return runtime.bound_outputs[output_index] != null;
            }

            pub fn outputBindingsOverlap(runtime: *const Self) bool {
                if (comptime OutputPlan.output_binding != .bound) return false;
                for (runtime.bound_outputs, 0..) |maybe_output, output_index| {
                    const output = maybe_output orelse continue;
                    for (runtime.bound_sources) |maybe_source| {
                        const source = maybe_source orelse continue;
                        if (slicesOverlap(output, source)) return true;
                    }
                    for (runtime.bound_outputs[0..output_index]) |maybe_previous| {
                        const previous = maybe_previous orelse continue;
                        if (slicesOverlap(output, previous)) return true;
                    }
                }
                return false;
            }

            pub fn outputLayout(comptime output_index: usize) Tensor.Layout(capacities.max_rank) {
                return outputInfo(output_index).layout;
            }

            /// Copy logical row-major values into a runtime-owned source. Lowering
            /// may select another physical layout; this method performs the
            /// corresponding one-time packing.
            pub fn copySource(
                runtime: *Self,
                comptime source_key: SourceKey,
                values: []const sourceScalar(source_key),
            ) SourceError!void {
                const source_id = comptime sourceIndex(source_key);
                if (comptime SourcePlan.source_bindings[source_id] != .owned) {
                    @compileError("copySource requires runtime-owned source storage");
                }
                const source = comptime sourceFor(source_key);
                const bytes = std.mem.sliceAsBytes(values);
                const expected_bytes = comptime sourceByteCount(source_key);
                if (bytes.len != expected_bytes) return error.SourceSizeMismatch;
                const destination = runtime.tensorView(source.tensor);
                for (values, 0..) |value, logical_index| {
                    destination.storage[destination.elementOffsetFromLinear(logical_index)] = value;
                }
            }

            /// Copy one runtime input into its runtime-owned region.
            pub fn copyInput(
                runtime: *Self,
                comptime source_key: SourceKey,
                values: []const sourceScalar(source_key),
            ) SourceError!void {
                const source = comptime sourceFor(source_key);
                comptime requireInput(source);
                try runtime.copySource(source_key, values);
            }

            /// Borrow runtime input storage without copying it. Values must use
            /// the physical order returned by sourceLayout(). The caller must keep
            /// the slice alive and unchanged for the duration of run().
            pub fn bindInput(
                runtime: *Self,
                comptime source_key: SourceKey,
                values: []const sourceScalar(source_key),
            ) SourceError!void {
                const source = comptime sourceFor(source_key);
                comptime requireInput(source);
                const source_id = comptime sourceIndex(source_key);
                if (comptime SourcePlan.source_bindings[source_id] != .bound) {
                    @compileError("bindInput requires the source to be configured as zgc.memory.Source.bound");
                }
                const bytes = std.mem.sliceAsBytes(values);
                const expected_bytes = comptime sourceByteCount(source_key);
                if (bytes.len != expected_bytes) return error.SourceSizeMismatch;
                runtime.bound_sources[source_id] = bytes;
            }

            pub fn inputIsBound(runtime: *const Self, comptime source_key: SourceKey) bool {
                const source = comptime sourceFor(source_key);
                comptime requireInput(source);
                const source_id = comptime sourceIndex(source_key);
                if (comptime SourcePlan.source_bindings[source_id] != .bound) {
                    @compileError("inputIsBound requires a runtime-bound input source");
                }
                return runtime.bound_sources[source_id] != null;
            }

            pub fn sourceLayout(
                comptime source_key: SourceKey,
            ) Tensor.Layout(capacities.max_rank) {
                return sourceInfo(source_key).layout;
            }

            inline fn executeNode(runtime: *Self, comptime node_id: usize) void {
                const node = graph.nodes[node_id].?;
                const compute = switch (node.op) {
                    .compute => |op| op,
                    .view => return,
                };
                const InputViews = comptime blk: {
                    var input_types: [node.input_count]type = undefined;
                    for (0..node.input_count) |input_index| {
                        const tensor_id = graph.input_refs[node.input_start + input_index].?;
                        input_types[input_index] = Validated.ConstView(tensor_id);
                    }
                    break :blk @Tuple(&input_types);
                };

                var inputs: InputViews = undefined;
                inline for (0..node.input_count) |input_index| {
                    const tensor_id = comptime graph.input_refs[node.input_start + input_index].?;
                    inputs[input_index] = runtime.constTensorView(tensor_id);
                }

                const OutputViews = comptime blk: {
                    var output_types: [node.output_count]type = undefined;
                    for (0..node.output_count) |output_index| {
                        const tensor_id = graph.output_refs[node.output_start + output_index].?;
                        output_types[output_index] = Validated.View(tensor_id);
                    }
                    break :blk @Tuple(&output_types);
                };
                var outputs: OutputViews = undefined;
                inline for (0..node.output_count) |output_index| {
                    const tensor_id = comptime graph.output_refs[node.output_start + output_index].?;
                    outputs[output_index] = runtime.tensorView(tensor_id);
                }

                compute.execute(inputs, outputs);
            }

            fn tensorView(runtime: *Self, comptime tensor_id: Tensor.Id) blk: {
                break :blk Validated.View(tensor_id);
            } {
                const info = graph.tensors[tensor_id].?;
                const T = info.dtype.Scalar();
                const bytes = runtime.tensorBytes(info.storage_tensor);
                const aligned_bytes: []align(@alignOf(T)) u8 = @alignCast(bytes);

                return .{
                    .storage = std.mem.bytesAsSlice(T, aligned_bytes),
                };
            }

            fn constTensorView(runtime: *const Self, comptime tensor_id: Tensor.Id) blk: {
                break :blk Validated.ConstView(tensor_id);
            } {
                const info = graph.tensors[tensor_id].?;
                const T = info.dtype.Scalar();
                const aligned_bytes = runtime.constTensorBytes(info.storage_tensor, T);

                return .{
                    .storage = std.mem.bytesAsSlice(T, aligned_bytes),
                };
            }

            fn tensorBytes(runtime: *Self, comptime tensor_id: Tensor.Id) []u8 {
                if (comptime OutputPlan.outputForRoot(tensor_id)) |output_index| {
                    return runtime.bound_outputs[output_index] orelse @panic("runtime output has not been bound");
                }
                const region = plan.tensor_regions[tensor_id] orelse
                    @compileError("tensor does not have runtime-owned mutable storage");
                return runtime.memory[region.offset .. region.offset + region.len_bytes];
            }

            fn constTensorBytes(
                runtime: *const Self,
                comptime tensor_id: Tensor.Id,
                comptime T: type,
            ) []align(@alignOf(T)) const u8 {
                const info = graph.tensors[tensor_id].?;
                if (comptime OutputPlan.outputForRoot(tensor_id)) |output_index| {
                    const bytes = runtime.bound_outputs[output_index] orelse @panic("runtime output has not been bound");
                    return @alignCast(bytes);
                }
                return switch (comptime SourcePlan.bindingForTensor(info)) {
                    .owned => blk: {
                        const region = plan.tensor_regions[tensor_id].?;
                        const bytes = runtime.memory[region.offset .. region.offset + region.len_bytes];
                        break :blk @alignCast(bytes);
                    },
                    .bound => blk: {
                        const source_id = switch (info.origin) {
                            .source => |id| id,
                            .node, .literal => unreachable,
                        };
                        const bytes = runtime.bound_sources[source_id] orelse
                            @panic("runtime input has not been bound");
                        break :blk @alignCast(bytes);
                    },
                    .embedded => |embedded| blk: {
                        const Embedded = switch (embedded.order) {
                            .logical => if (comptime hasLogicalRowMajorLayout(info))
                                EmbeddedStorage(embedded.bytes, @alignOf(T))
                            else
                                PackedEmbeddedStorage(
                                    embedded.bytes,
                                    info,
                                    @alignOf(T),
                                ),
                            .physical => EmbeddedStorage(embedded.bytes, @alignOf(T)),
                        };
                        break :blk &Embedded.storage;
                    },
                    .literal => |value| blk: {
                        const Literal = LiteralStorage(value);
                        break :blk std.mem.asBytes(&Literal.storage);
                    },
                };
            }

            fn sourceIndex(comptime source_key: SourceKey) usize {
                const source_id: usize = @intCast(@backingInt(source_key));
                if (source_id >= graph.sources.len or graph.sources[source_id] == null) {
                    @compileError("the graph does not contain the provided source key");
                }
                return source_id;
            }

            fn outputInfo(comptime output_index: usize) @TypeOf(graph).TensorInfo {
                if (output_index >= graph.output_ct) @compileError("output index is outside the graph's outputs");
                return graph.tensors[graph.outputs[output_index].?].?;
            }

            fn outputScalar(comptime output_index: usize) type {
                return outputInfo(output_index).dtype.Scalar();
            }

            fn slicesOverlap(lhs: []const u8, rhs: []const u8) bool {
                if (lhs.len == 0 or rhs.len == 0) return false;
                const lhs_start = @intFromPtr(lhs.ptr);
                const rhs_start = @intFromPtr(rhs.ptr);
                return if (lhs_start <= rhs_start)
                    rhs_start - lhs_start < lhs.len
                else
                    lhs_start - rhs_start < rhs.len;
            }

            fn sourceFor(comptime source_key: SourceKey) Tensor.Source {
                return graph.sources[sourceIndex(source_key)].?;
            }

            fn sourceInfo(comptime source_key: SourceKey) @TypeOf(graph).TensorInfo {
                return graph.tensors[sourceFor(source_key).tensor].?;
            }

            fn sourceScalar(comptime source_key: SourceKey) type {
                return sourceInfo(source_key).dtype.Scalar();
            }

            fn sourceByteCount(comptime source_key: SourceKey) usize {
                const info = sourceInfo(source_key);
                return info.shape.elementCount() * info.dtype.byteSize();
            }

            fn requireInput(comptime source: Tensor.Source) void {
                if (source.kind != .input) @compileError("source is not a runtime input");
            }
        };
    };
}
